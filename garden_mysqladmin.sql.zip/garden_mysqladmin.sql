-- phpMyAdmin SQL Dump
-- version 3.3.8.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 05, 2013 at 09:38 AM
-- Server version: 5.0.91
-- PHP Version: 5.3.6-pl0-gentoo

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `garden_mysqladmin`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL auto_increment,
  `product_code` varchar(60) default NULL,
  `product_name` varchar(60) NOT NULL,
  `product_desc` tinytext NOT NULL,
  `product_img_name` varchar(60) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `product_code` (`product_code`),
  KEY `product_code_2` (`product_code`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=92 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_code`, `product_name`, `product_desc`, `product_img_name`, `price`) VALUES
(74, NULL, 'Android Phone', 'Product Description\r\nProduct: HTC Thunderbolt 4G LTE- Verizon\r\nNetworks: LTE 700, CDMA EvDO revA\r\nPlatform: Android 2.2 + HTC Sense Current software number: 2.11.605.5\r\nDisplay: 4.3" WVGA TFT capacitive touch screen\r\nCamera: 8MP with autofocus, LED Flash ', 'android-phone.jpg', 399.00),
(76, NULL, 'LCD TV', '26 (16:9) Wide TFT LCD; Display 16:9 (1366 x 768); Contrast 800:1;Response time 8ms (Grey to Grey); 3 D Comb Filter; Mount Vesa 100; Energy Star. DVD Features: DVD Plays: DVD, CD-DA, CD-R/RW, DVD-R/RW (Only Video Format); MP 3/JPEG/WMA; DTS. Jack Configur', 'lcd-tv.jpg', 200.00),
(79, NULL, 'CANON Digital Ixus 132 - black', '16.0 Megapixels capture fine detail\r\n\r\nCapturing all the detail from the genuine Canon lens the 16MP sensor delivers superb quality images that are perfect for large-scale prints (A3+) or creative cropping.\r\n\r\n\r\nGet closer: 8x zoom lens, 28mm wide-angle\r\n', 'canon1.jpg', 150.00),
(80, NULL, 'SAMSUNG Series 3 NP3530EC - blue grey ', 'The Series 3 NP3530EC from Samsung has been designed for life on the move. Its Lithium-Ion battery offers prolonged operation without a mains connection, so you can work and play anywhere and everywhere.\r\n\r\nThe notebook uses the Microsoft Windows® 8 O.S. ', 'samsung.jpg', 500.00),
(81, NULL, 'GARMIN 3597 GPS nüvi LMT Europe', 'The Garmin nüvi  3597 LMT GPS has a TFT screen of 5 inches and free mapping updates. This browser bypasses traffic jams and delays with its Premium traffic info receiver.\r\n\r\nWith Garmin Real navigation, the nüvi 3597 LMT uses visual cues to guide you effe', 'garmin.jpg', 180.00),
(82, NULL, 'APPLE iPod touch 16 GB black (4th generation)', 'Product details\r\nMemory capacity : 16 GB\r\nScreen : 3.5-inch (diagonal) widescreen\r\nRadio tuner : No\r\nVideo playback : Yes\r\nWeight (g) : 101', 'iphone.jpg', 170.00),
(83, NULL, 'BEATS BY DR.DRE Monster Beats Solo with ControlTalk Headphon', 'Designed to let you listen to music on an MP3 player or smartphone, the Monster Beats by Dr. Dre Solo headphones from MonsterCable feature a trendy design and high quality performance.\r\n\r\nDeveloped by the famous rapper Dr. Dre, the Monster Beats by Dr. Dr', 'head.jpg', 199.00),
(84, NULL, 'CANON EF-S 55-250 mm f/4-5.6 IS II Lens', 'This EF-S 55-250mm f/4-5.6 IS telephoto zoom lens from Canon comes with a 4-speed image stabiliser and is made up of a system of 12 glass elements, which are divided up into 10 groups. \r\n\r\nThe circular aperture diaphragm is ideal for emphasising subjects ', 'lense.jpg', 250.00),
(85, NULL, 'COWON/IAUDIO COWON X9 MP4 FM player - 32 GB - black', 'Product details\r\nMemory capacity : 32 GB\r\nScreen : 4.3" touch screen (10.9 cm)\r\nRadio tuner : FM\r\nVideo playback : Yes\r\nWeight (g) : 159g', 'mp3.jpg', 219.00),
(86, NULL, 'LG 50PN6500 plasma television', 'With stunning displays and a stunning design, the 50PN6500 plasma television from LG makes an impressive addition to your home entertainment set-up, plunging you right into the heart of the action by delivering rich, detailed and super sharp images. \r\n\r\nA', 'plasma.jpg', 600.00),
(87, NULL, 'LENOVO Yoga 11', 'Somewhere between a laptop and a tablet, the Yoga 11 from Lenovo includes an NVIDIA Tegra 3 T30 processor and Microsoft Windows® RT.\r\n\r\nThe 11.6" HD touch screen can be completely tilted to comfortably view films and photos. Plus, the Yoga 11 features wir', 'lenovo.jpg', 699.00),
(88, NULL, 'LEGO 75003 Star Wars - A-wing Starfighter', 'Bring the battle to the evil Empire with the Rebel Alliance''s super-fast A-wing Starfighter! As featured in Star Wars™: Episode VI Return of the Jedi™, the agile A-wing, with an opening cockpit, is perfect for attacking the Imperial Fleet! Build the same ', 'lego.jpg', 30.00),
(89, NULL, 'NUMATIC HVR200 Henry Vacuum Cleaner', 'Be greeted with a smile every time you do the housework with this Numatic HVR200 Henry Vacuum Cleaner!  \r\n\r\nThe HVR200 Henry Vacuum Cleaner boasts 1200W power and is lightweight and easy to move around. Plus, it''s equipped with a cable winder to take the ', 'cleaner.jpg', 325.00),
(90, NULL, 'GARMIN Zumo 660LM motorbike GPS for Europe', 'Whether you''re on a bike or driving a car, the sturdy Zumo 660LM from Garmin will resist anything. In fact, the 660LM''s case is waterproof to IPX7 and resistant to fuel sprays and UV rays, so it''s ready for life on the open road!\r\n\r\nWith maps covering 45 ', 'gps.jpg', 245.00),
(91, NULL, 'PHILIPS SBP1120 Portable Speakers', 'With a total output power of 2 W, these Philips SBP1120 portable speakers have been specially designed to go with you everywhere. No batteries are required - just plug and play!\r\n\r\nIn fact, these compact SBP1120 travel speakers get their power directly fr', 'speaker.jpg', 100.00);

-- --------------------------------------------------------

--
-- Table structure for table `tweets`
--

CREATE TABLE IF NOT EXISTS `tweets` (
  `twitteid` int(11) NOT NULL auto_increment,
  `productid` text NOT NULL,
  `dtime` datetime default NULL,
  `twittetext` text,
  `userid` int(11) NOT NULL,
  PRIMARY KEY  (`twitteid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tweets`
--

INSERT INTO `tweets` (`twitteid`, `productid`, `dtime`, `twittetext`, `userid`) VALUES
(19, '', '2013-07-30 11:37:49', 'tweet checker..', 24),
(8, '', '2013-07-29 16:23:17', 'testing twitte', 23),
(9, '', '2013-07-29 16:27:46', 'testin 12323', 23),
(10, '', '2013-07-29 16:28:24', 'terere', 23),
(11, '', '2013-07-29 16:33:11', 'testing tweete management', 23),
(12, '', '2013-07-29 16:38:18', 'testered', 23),
(13, '', '2013-07-29 16:38:31', 'tesrere', 23),
(14, '', '2013-07-29 16:39:14', 'testing 1', 23),
(15, '', '2013-07-29 16:47:38', 'testing 1.2', 23),
(16, '', '2013-07-29 16:49:22', 'testin 2.0', 23),
(17, '', '2013-07-29 16:55:15', 'testing twette management', 23),
(18, '', '2013-07-29 16:57:46', 'testing\r\n', 23),
(20, '', '2013-07-30 12:08:10', 'this is a test tweet. to make sure it''s working', 25),
(21, '', '2013-07-31 13:19:49', 'Great offer LCD TV discounted price 200.00', 76),
(22, '', '2013-08-01 16:29:32', 'Great offer Android Phone discounted price 399.00', 74),
(23, '', '2013-08-03 02:24:02', 'Final testing..', 24),
(24, '', '2013-08-03 02:24:10', 'Great offer LCD TV discounted price 200.00', 76),
(25, '', '2013-08-03 08:33:09', 'a new canon camera added to the products list', 25),
(26, '', '2013-08-03 21:24:27', 'Great offer GARMIN 3597 GPS nüvi LMT Europe discounted price 180.00', 81),
(27, '', '2013-08-04 14:56:20', 'a lot of new products added to the products page', 25);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL auto_increment,
  `email` varchar(70) default NULL,
  `oauth_uid` varchar(200) default NULL,
  `oauth_provider` varchar(200) default NULL,
  `username` varchar(100) default NULL,
  `gender` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `oauth_uid`, `oauth_provider`, `username`, `gender`, `password`) VALUES
(24, 'imtiaz@gmail.com', NULL, NULL, 'imtiaz', '', 'imtiaz'),
(25, 'imtiaz818@gmail.com', NULL, NULL, 'imtiaz', '', '12345'),
(26, 'test@gmail.com', NULL, NULL, 'test', '', 'test');
