<?php
  phpinfo();

?>
        
    