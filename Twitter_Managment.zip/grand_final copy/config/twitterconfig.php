<?php

/*
    define('CONSUMER_KEY', '6twNHg85I0Wztp01vsgww');
    define('CONSUMER_SECRET', '9f2hntbtSf0RTuFnHIEyJnx8IJnbFAhCewvKiHVcHY');
    define('OAUTH_TOKEN', '1322201706-n0aOfICRe5b8ot2ahCbDbE5MW5QUyitI1uMMIbe');
    define('OAUTH_SECRET', 'R5Rv2IYJSDU0JYvs7xrLk6PVCBBZi8IjpFOkolENuU');
*/	
	
	define('CONSUMER_KEY', 'jchyNKAowbjEit83mxkZfw');
    define('CONSUMER_SECRET', 'By8AW8fw3GwvHeBcD5edxcaW0UG2Q5UK1Eam20ZvHU');
    define('OAUTH_TOKEN', '1322201706-oa7CDSCjY1MZdB3WaDkO5Dvca15PvJ9CNzMNO4m');
    define('OAUTH_SECRET', 'PfGPaZCzaANCQzbTbn9gxfdk2jkiwZb5CnXTmqC6vo');


?>
