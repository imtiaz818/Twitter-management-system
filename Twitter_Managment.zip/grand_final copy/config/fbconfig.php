<?php
    define('APP_ID', '423601227719582');
    define('APP_SECRET', '9a43b5bdab484a72bdb7d89367fdc0cb');
?>
